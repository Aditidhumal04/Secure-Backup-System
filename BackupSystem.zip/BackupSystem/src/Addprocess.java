

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormProcess
 */
@WebServlet("/Addprocess")
public class Addprocess extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	//String c="carpenter";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	

	
	
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	//String compno=request.getParameter("compno");
    	String nme=request.getParameter("nme");
		
		String cno=request.getParameter("cno");
		String email=request.getParameter("email");
		
		
		
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","root"); 
			if(con!= null ) {
				System.out.println("Connection Established");
				
				
				
				
				PreparedStatement stmt=con.prepareStatement( "INSERT INTO backupdb VALUES ( default,?,?,?,default,default)");  
				stmt.setString(1,nme);//1 specifies the first parameter in the query 
				stmt.setString(2,email);
				stmt.setString(3,cno); 
				
				
				
				  
				int i=stmt.executeUpdate();
				System.out.println(i);
				if(i==0) {
					
					String redirectURL = "adddetail.jsp";
			        response.sendRedirect(redirectURL);
				
				}else {
					String redirectURL = "addlast.jsp";
			        response.sendRedirect(redirectURL);
				}
			}
			else {
				System.out.println("Connection not Established");
				String redirectURL = "adddetail.jsp";
		        response.sendRedirect(redirectURL);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} 
		
		
		
		/*
		//System.out.println("complaint no is"+compno);
		//System.out.println("name is"+nme);
		System.out.println("department is"+dept);
		System.out.println("location is"+loc);
		//System.out.println("nature of complaint  is"+noc);
		System.out.println("complaint is"+complaint);
		System.out.println("date is"+dte);
		
		
		
		//request.getSession().setAttribute("complaint no", compno);
		//request.getSession().setAttribute("nme", nme);
		request.getSession().setAttribute("dept", dept);
		request.getSession().setAttribute("loc", loc);
		//request.getSession().setAttribute("noc", noc);
		request.getSession().setAttribute("complaint", complaint);
		request.getSession().setAttribute("date ", dte);
		
		
		//response.sendRedirect("displayfromdb.jsp");*/
		
	}
    
    
    
  
    
  

}
